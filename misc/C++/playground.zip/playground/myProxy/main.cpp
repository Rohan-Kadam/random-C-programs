#include <iostream>

#define BOOST_ASIO_ENABLE_HANDLER_TRACKING
#include <boost/asio.hpp>

using namespace boost;
using namespace boost::asio::ip;

class Connection;

class Server
{
public:
	void notify_remove_connection(Connection*);
	tcp::resolver& resolver() { return resolver_; } //  for static singleton class it should be fine...
	Server(asio::io_context& ioc, unsigned short port) :
		ioc_{ioc},
		acceptor_{ioc_,tcp::endpoint{tcp::v4(), port}},
		resolver_{ioc} { // check for throws
			acceptor_.async_accept(std::bind(&Server::accept_handler, this, std::placeholders::_1, std::placeholders::_2));
	}
	~Server() {
		std::cout << "closing server...\n";
		acceptor_.close();
	}
private:
	void accept_handler(const system::error_code& ec, tcp::socket sock);
	asio::io_context& ioc_; // not the owner of ioc
	tcp::acceptor acceptor_;
	tcp::resolver resolver_;
	std::vector<std::unique_ptr<Connection>> connections_; //using a vector for now... can be changed to set/heap
};

class Connection
{
public:
	static std::unique_ptr<Connection> make_new_connection(Server& parent, tcp::socket&& sock) {
		return std::unique_ptr<Connection>{new Connection{parent, std::move(sock)}};
	}
	~Connection() { std::cout << "[connection] destroyed\n"; sock_in_.close(); }; // check for throws
private:
	void peer_read_handler(int direction, const system::error_code& ec, std::size_t bytes);
	void peer_write_handler(int direction, const system::error_code& ec, std::size_t bytes);
	void in_request_handler(const system::error_code& ec, std::size_t bytes);
	void out_connect_handler(const system::error_code& ec);
	void do_setup_outbound(const std::string& host);
	void do_close();
	Connection(Server& parent, tcp::socket&& sock):
		parent_(parent),
		sock_in_{std::move(sock)},
		sock_out_{sock_in_.get_executor()} {
		std::cout << "[connection] new\n";
		asio::async_read_until(sock_in_, in_buff_, "\r\n\r\n",
			std::bind(&Connection::in_request_handler, this, std::placeholders::_1, std::placeholders::_2));
	};
	Server& parent_; // remove this later. make server a static signleton class
	tcp::socket sock_in_; // this class is the owner
	tcp::socket sock_out_; // this class is the owner
	asio::streambuf in_buff_;
	asio::streambuf out_buff_;
	// from the HTTP request line
	std::string req_line_;  // GET / HTTP/1.1 or CONNECT www.google.com HTTP/1.1
	std::string req_host_;  // www.google.com or www.google.com:443
	enum {OTHER, CONNECT} req_type_;
	std::vector<std::string> req_headers_;
	int close_flag_ = 1;
};
void Connection::do_close() {
//	std::cout << "closing connection...\n";
	sock_in_.close();
	sock_out_.close();
	if(close_flag_) {
		parent_.notify_remove_connection(this); // ignore this for now...
		close_flag_ = 0;
	}
}
void Connection::peer_read_handler(int direction, const system::error_code& ec, std::size_t bytes) {
//	std::string dir = direction == 0 ? "out" : "in";
//	std::cout << "[peer read] " << dir << " : " << ec.message() << ", " << bytes << "\n";
	if(!ec || ( ec == asio::error::eof && bytes > 0 )){
//		std::cout << dir << bytes << " read...\n";
		tcp::socket& sock_other = direction == 0 ? sock_in_ : sock_out_;
		asio::streambuf& buff = direction == 0 ? out_buff_ : in_buff_;
		buff.commit(bytes);
		asio::async_write(sock_other, asio::buffer(buff.data(), bytes),
			std::bind(&Connection::peer_write_handler, this, !direction, std::placeholders::_1, std::placeholders::_2));
	};
	if(ec){
		do_close();
	}
}
void Connection::peer_write_handler(int direction, const system::error_code& ec, std::size_t bytes) {
//	std::string dir = direction == 0 ? "out" : "in";
//	std::cout << "[peer write] " << dir << " : " << ec.message() << ", " << bytes << "\n";
	if(!ec && bytes > 0){
//		std::cout << dir << bytes << " written...\n";
		tcp::socket& sock_other = direction == 0 ? sock_in_ : sock_out_;
		asio::streambuf& buff_other = direction == 0 ? in_buff_ : out_buff_;
		buff_other.consume(bytes);
		//asio::async_read(sock_other, buff_other,
		//	std::bind(&Connection::peer_read_handler, this, !direction, std::placeholders::_1, std::placeholders::_2));
		sock_other.async_read_some(buff_other.prepare(1024),
			std::bind(&Connection::peer_read_handler, this, !direction, std::placeholders::_1, std::placeholders::_2));
	}else{
		do_close();
	}
}
void Connection::out_connect_handler(const system::error_code& ec) {
	if (!ec) {
		std::cout << "[outbound] connected\n";
		if (req_type_ == CONNECT) {
			std::ostream os{&out_buff_};
			os << "HTTP/1.1 200 Connection established\r\n";
			os << "Proxy-Agent: The awesome proxy server\r\n";
			os << "\r\n";
			asio::async_write(sock_in_, out_buff_,
				std::bind(&Connection::peer_write_handler, this, 1, std::placeholders::_1, std::placeholders::_2));
			//asio::async_read(sock_in_, in_buff_,
			//	std::bind(&Connection::peer_read_handler, this, 1, std::placeholders::_1, std::placeholders::_2));
			sock_in_.async_read_some(in_buff_.prepare(1024),
				std::bind(&Connection::peer_read_handler, this, 1, std::placeholders::_1, std::placeholders::_2));
		}else{
			std::ostream os{&in_buff_};
			os << req_line_ << "\r\n";
			for (const auto& line : req_headers_){
				os << line << "\r\n";
			}
			os << "\r\n";
			asio::async_write(sock_out_, in_buff_,
				std::bind(&Connection::peer_write_handler, this, 0, std::placeholders::_1, std::placeholders::_2));
			sock_out_.async_read_some(out_buff_.prepare(1024),
				std::bind(&Connection::peer_read_handler, this, 0, std::placeholders::_1, std::placeholders::_2));
			//asio::async_read(sock_out_, out_buff_,
			//	std::bind(&Connection::peer_read_handler, this, 0, std::placeholders::_1, std::placeholders::_2));
		}
	}else{
		std::cout << "[outbound] error connecting: " << ec.message() << "\n";
		do_close();
	}
}
void Connection::do_setup_outbound(const std::string& host) {
	// extract port hungama... i hate string manipulations
	auto m = host.find(':');
	std::string port = "80";
	std::string host_name = host;
	if (m != static_cast<size_t>(-1)) {
		port = host.substr(m+1);
		host_name = host.substr(0,m);
	}
	std::cout << "[outbound] connect to: " << host_name << " " << port << "\n";
	// blocking resolve is fine as this will be in the same strand as inbound sock...
	auto endpoints = parent_.resolver().resolve(host_name, port);
	asio::async_connect(sock_out_, endpoints,
		std::bind(&Connection::out_connect_handler, this, std::placeholders::_1));
}
void Connection::in_request_handler(const system::error_code& ec, std::size_t bytes) {
	if (!ec) {
		std::cout << "[inbound] request received...\n";
		in_buff_.commit(bytes);
		std::istream is(&in_buff_); // adapt buffer into istream
		std::getline(is, req_line_, '\r');
		char ch;
		is >> std::noskipws >> ch;
		req_type_ = req_line_.substr(0,7) == "CONNECT" ? CONNECT : OTHER;
		// is there a better way to iterate over the request lines??
		while(is){
			std::string line;
			std::getline(is, line, '\r');
			is >> std::noskipws >> ch;
			if (line == "") break;
			// The if-else ladder can be improved
			if (line.substr(0,5) == "Host:"){
				req_host_ = line.substr(6);
//				std::cout << "[request] req_host_: " << req_host_ << "\n";
			}
			req_headers_.push_back(std::move(line));
			//std::cout << "[request header] " << line << "\n";
		}
		in_buff_.consume(bytes);
		do_setup_outbound(req_host_);
//		std::cout << "[request ended]\n";
//		asio::async_read_until(sock_in_, in_buff_, "\r\n\r\n",
//			std::bind(&Connection::in_request_handler, this, std::placeholders::_1, std::placeholders::_2));
	}else{
		std::cout << "[connection] read error: " << ec.message() << "\n";
		do_close();
	}
}


void Server::notify_remove_connection(Connection* con_ptr) { // this function is bad...
	asio::post(ioc_, [con_ptr,this]() {
//		std::cout << "[Server] executing posted remove connection...\n";
		for (auto i = connections_.begin(); i != connections_.end();i++ ) {
			if (i->get() == con_ptr){
				connections_.erase(i);
				break;
			}
		}
		std::cout << "[Server]: active connections: " << connections_.size() << "\n";
	});
}
void Server::accept_handler(const system::error_code& ec, tcp::socket sock) {
//	std::cout << "incoming connection...\n";
	if (!ec) {
		connections_.push_back(Connection::make_new_connection(*this, std::move(sock)));
		std::cout << "[Server]: active connections: " << connections_.size() << "\n";
	}
	// re-bind the acceptor
	acceptor_.async_accept(std::bind(&Server::accept_handler, this, std::placeholders::_1, std::placeholders::_2));
}
int main() {
	std::cout << "starting server...\n";
	asio::io_context ioc;
	Server s{ioc, 8080};
	ioc.run();
	std::cout << "exiting...\n";
	return 0;
}
