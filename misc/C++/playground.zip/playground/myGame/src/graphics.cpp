#include <functional>
#include <experimental/timer>
#include <graphics.h>

//extern SDL_Texture* CAR_TEX;

static SDL_Texture* ARROW_TEX;

std::shared_ptr<MovableGraphicsObject> MovableGraphicsObject::make_new(SDL_Renderer* ren, std::shared_ptr<MovableObject> obj_ptr, std::string model) {
	return std::shared_ptr<MovableGraphicsObject>{new MovableGraphicsObject{ren, obj_ptr, model}};
}

void MovableGraphicsObject::render(SDL_Renderer* ren) {
	Position pos = position();
	CoordinatePair loc = pos.location;
	SDL_Rect rect {.x = loc.first-25, .y = loc.second - 25, .w = 50, .h = 50};
	SDL_Rect arrow_rect {.x = loc.first, .y = loc.second - 25, .w = 50, .h = 50};
	SDL_Point point {.x = 0, .y = 25};
	SDL_RenderCopyEx(ren, ARROW_TEX, NULL, &arrow_rect, pos.orientation * 180/3.141592, &point, SDL_FLIP_NONE);
	SDL_RenderCopy(ren, model_tex_, NULL, &rect);
}

MovableGraphicsObject::MovableGraphicsObject(SDL_Renderer* ren, std::shared_ptr<MovableObject> obj_ptr, std::string model) :
	obj_ptr_{obj_ptr}, obj_{*obj_ptr}, model_(model) {
	auto surf = IMG_Load(("resources/"+model_+".png").data());
	if(!surf) throw std::runtime_error{std::string{"IMG_Load error: "} + SDL_GetError()};
	// Dont know how to delete surf XXX TODO
	model_tex_ = SDL_CreateTextureFromSurface(ren, surf);
	if(!model_tex_) throw std::runtime_error{std::string{"SDL_CreateTextureFromSurface error: "} + SDL_GetError()};
}
MovableGraphicsObject::~MovableGraphicsObject() {
	if (model_tex_) SDL_DestroyTexture(model_tex_);
}
void GraphicsObject::render(SDL_Renderer* ren) {
	std::cout << "[render @" << this << "] position: " << position().location << "\n";
}
const Position& MovableGraphicsObject::position() const {
	auto fut = obj_.position();
	auto ptr = fut.get();
	return *ptr;
}
void GraphicsEngine::stop() {
	post(ex_, [this] {
		stop_requested_ = true;
	});
	ex_.join();
}
void GraphicsEngine::run() {
	post_after(std::chrono::milliseconds{50}, ex_,
		std::bind(&GraphicsEngine::render_frame, this));
}
void GraphicsEngine::render_frame() {
	if (stop_requested_) return;
	SDL_RenderClear(renderer_);
	// Can be made awesome with for_each
	// Also objs_ must actually be a graph, which can capture Z-order
	// however Z-order can change at run time so would be quite difficult
	// So what should be done is that the GraphicsEngine must keep tabs on the position of each
	// MovableObject and reflect it on the graph. Then render each obj accordingly.
	// That would be insanely awesome and difficult
	for (auto obj : objs_){
		obj->render(renderer_);
	}
	SDL_RenderPresent(renderer_);
	post_after(std::chrono::milliseconds{50}, ex_,
		std::bind(&GraphicsEngine::render_frame, this));
}

void GraphicsEngine::remove_obj(GraphicsObject* obj) { // bad function... ignore
	defer(ex_, [this,obj] {
		for(auto i = objs_.begin(); i != objs_.end(); i++){
			if ((*i).get() == obj){
				objs_.erase(i);
			}
		}
	});
}
void GraphicsEngine::insert_obj(std::shared_ptr<GraphicsObject> obj) {
	defer(ex_, [this,obj] {
		objs_.push_back(obj);
	});
}
GraphicsEngine::GraphicsEngine(SDL_Window* win) : ex_{1} {
	renderer_ = SDL_CreateRenderer(win, -1, SDL_RENDERER_ACCELERATED | SDL_RENDERER_PRESENTVSYNC);
	if (renderer_ == nullptr) throw std::runtime_error{std::string{"SDL_CreateRenderer error: "} + SDL_GetError()};
// tmp stuff:
	auto arrow_surf = IMG_Load("resources/arrow.png");
	if(!arrow_surf) throw std::runtime_error{std::string{"IMG_Load error: "} + SDL_GetError()};
	// Dont know how to delete surf XXX TODO
	ARROW_TEX = SDL_CreateTextureFromSurface(renderer_, arrow_surf);
	if(!ARROW_TEX) throw std::runtime_error{std::string{"SDL_CreateTextureFromSurface error: "} + SDL_GetError()};
}
GraphicsEngine::~GraphicsEngine(){
	if(renderer_) SDL_DestroyRenderer(renderer_);
}

/*
int main() {
	if (SDL_Init(SDL_INIT_VIDEO) != 0) {
		std::cout << "SDL_Init Error: " << SDL_GetError() << "\n";
		return 1;
	}
	SDL_Window *win = SDL_CreateWindow("myGame", (2560-640)/2, (1080-480)/2, 640, 480, SDL_WINDOW_SHOWN);
	if (win == nullptr) {
		std::cout << "SDL_CreateWindow Error: " << SDL_GetError() << "\n";
		SDL_Quit();
		return 1;
	}
	thread_pool pool;
	GraphicsEngine engine{pool.get_executor(), win};
	StaticGraphicsObject bkg {"resources/background.png"};
	engine.insert_obj(&bkg);
	engine.render_frame();
	pool.join();
	SDL_Delay(3000);
	return 0;
}
*/
