#include <game.h>
#include <functional>
#include <experimental/timer>
#include <experimental/future>
#include <chrono>

std::shared_ptr<MovableObject> MovableObject::make_new(const thread_pool& pool) {
	return std::shared_ptr<MovableObject>{ new MovableObject(pool) };
}
std::future< const Position* > MovableObject::position() const {
	return defer(ex_, [this] ()-> const Position* {
		return &position_;
	},
	use_future);
}
void MovableObject::MoveAction::setup_rotate(const CoordinatePair& d) {

}
void MovableObject::MoveAction::setup_direct_move(const CoordinatePair& d) {
	update_action(d);
	if(!active) post_after(std::chrono::milliseconds{50}, obj.ex_,
		std::bind(&MoveAction::operator(), this));
	active = true;
}

void MovableObject::MoveAction::update_action(const CoordinatePair& d) {
	dst.location = d;
	tdv = d - obj.position_.location;
	auto dist = norm(tdv);
	dst.orientation = angle(obj.position_.location, d);
	auto ang_dist =  dst.orientation - obj.position_.orientation;
	if (ang_dist > 3.141592) ang_dist = -2*3.141592 + ang_dist;
	if (ang_dist < -3.141592) ang_dist = 2*3.141592 + ang_dist;
	count = dist/obj.move_speed_*tps; // round down
	count2 = abs(ang_dist/obj.rotate_speed_*tps); // round down
	std::cout << "[MovableObject] rotate steps: " << count2 << "\n";
	// std::cout << "[MovableObject] steps to move: " << count << "\n";
	std::cout << "[MovableObject @" << this << "] move distance: " << dist << ", time: " << dist/obj.move_speed_ << "\n";
	tdv *= obj.move_speed_/dist/tps;
	tov = ang_dist / count2; // I am too lazy to think now... :-P
}

void MovableObject::MoveAction::operator()(void){
	while(count2) {
		obj.position_.orientation += tov;
		// obj.position_.orientation = fmod(obj.position_.orientation, 3.141592);
		// std::cout << "[MoveAction] orientation: " << obj.position_.orientation * 180/3.141592 << "\n";
		// std::cout << "count2: " << count2 << "\n";
		post_after(std::chrono::milliseconds{50}, obj.ex_,
			std::bind(&MoveAction::operator(), this));
		count2--;
		return;
	}
	obj.position_.orientation = dst.orientation;
	while(count){
		obj.position_.location += tdv;
		// std::cout << "[MoveAction] obj position: " << obj.position_.location << "\n";
		post_after(std::chrono::milliseconds{50}, obj.ex_,
			std::bind(&MoveAction::operator(), this));
		count--;
		return;
	}
	obj.position_.location = dst.location;
	active = false;
	// obj.action.release();
	// std::cout << "[MoveAction] obj final position: " << obj.position_.location << "\n";
}

void MovableObject::move(const CoordinatePair& dst) {
//	if (action) {action->setup_di }
//	action.reset(new MoveAction(*this, 20));
	post(ex_, std::bind(&MoveAction::setup_direct_move, action_.get(), dst) );
}
