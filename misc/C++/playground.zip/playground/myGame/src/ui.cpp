#include <iostream>
#include <ui.h>
#include <game.h>

//extern MovableObject* CAR;
void Ui::run(GameEngine& engine) {
	SDL_Event e;
	while (SDL_WaitEvent(&e)) { // blocking call
		if (e.type == SDL_QUIT)
			break;
		if (e.type == SDL_KEYDOWN) {
			std::cout << "[ui keydown] keysym.sym: " << e.key.keysym.sym << "\n";
			std::cout << "[ui keydown] keysym.mod: " << e.key.keysym.mod << "\n";
		}
		if (e.type == SDL_MOUSEBUTTONDOWN) {
			std::cout << "[ui mousebuttondown]  button.button: " << e.button.button << "\n";
			std::cout << "[ui mousebuttondown]  button.(x,y): (" << e.button.x << ", " << e.button.y << ")\n";
			SDL_Delay(60);
			engine.click_handler({e.button.x, e.button.y});
	//		CAR->move({e.button.x, e.button.y});
		}
	}
}

Ui::Ui() {
	if (SDL_Init(SDL_INIT_VIDEO) != 0)
		throw std::runtime_error{ std::string{"SDL_Init Error: "} + SDL_GetError()};
	win_ = SDL_CreateWindow("myGame", (2560-640)/2, (1080-480)/2, 640, 480, SDL_WINDOW_SHOWN);
	if (win_ == nullptr)
		throw std::runtime_error{ std::string{"SDL_CreateWindow Error: "} + SDL_GetError()};
}

Ui::~Ui() {
	if (win_) SDL_DestroyWindow(win_);
	SDL_Quit();
}
