#include <iostream>
#include <experimental/thread_pool>
#include <experimental/strand>
#include <SDL.h>
#include <SDL_image.h>
#include <game.h>
#include <graphics.h>
#include <ui.h>

//SDL_Texture* CAR_TEX;
//MovableObject* CAR;

int main() {

	Ui ui{};
	GraphicsEngine gEngine {ui.window()};
	GameEngine mEngine{};
	auto obj1 = mEngine.make_new_movable_object();
	auto gObj1 = gEngine.make_new_movable_object(obj1, "puck");
	gEngine.run();
	ui.run(mEngine);  // blocking call
	gEngine.stop();
	mEngine.stop();
	return 0;
}
