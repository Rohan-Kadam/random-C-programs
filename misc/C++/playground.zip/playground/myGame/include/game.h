#ifndef _GAME_
#define _GAME_

#include <memory>
#include <future>
#include <experimental/thread_pool>
#include <experimental/strand>
#include <coordinatepair.hpp>
#include <common.h>

using namespace std::experimental;

class MovableObject {
public:
	void move(const CoordinatePair& dst);
	std::future<const Position*> position() const;
	static std::shared_ptr<MovableObject> make_new(const thread_pool& pool);
private:
	struct MoveAction {
		MovableObject& obj;	// obj on which to act on
		//CoordinatePair dst;	// final destination
		Position dst;
		int tps;			// ticks per second
		int count;			// number of ticks it takes to finish the action
		int count2;			// number of ticks it takes to finish the action DONT WANT TO THINK...
		CoordinatePair tdv;	// tick displacement vector
		float tov;			// tick orientation value
		bool active;		// determines wether the action is active
		MoveAction(MovableObject& o, int t = 20): obj{o}, tps{t}, active{false} {};
		void operator()(void);
		void setup_direct_move(const CoordinatePair& dst);
		void update_action(const CoordinatePair& dst);
		void setup_rotate(const CoordinatePair& d);
	};

	MovableObject(const thread_pool& t) :ex_{t.get_executor()}, action_{new MoveAction{*this, 20}} {};
	Position position_ = {{0.0, 0.0},0.0};
	float move_speed_ = 175.0;	// dist. units/sec
	float rotate_speed_ = 2.5*3.14;	// radians/sec
	mutable strand<thread_pool::executor_type> ex_;
	std::unique_ptr<MoveAction> action_;
};

class GameEngine {
public:
	//GameEngine(GraphicsEngine& graphics) : graphics_ {graphics} {};
	GameEngine() {}
	std::shared_ptr<MovableObject> make_new_movable_object() { auto obj = MovableObject::make_new(pool_); objs_.push_back(obj); return obj;}
	void stop() {pool_.join();}
	void click_handler(const CoordinatePair loc) {
		objs_[0]->move(loc);
	}
private:
	std::vector<std::shared_ptr<MovableObject>> objs_;
	//GraphicsEngine& graphics_;
	thread_pool pool_;
};
#endif
/*
		MoveAction(const MoveAction& other) :
			obj{other.obj},
			dst{other.dst},
			tps{other.tps},
			count{other.count},
			tdv{other.tdv}
			{
				std::cout << "[MoveAction] copy constructor should not be called!!!! \n";
			}
		~MoveAction() { std::cout << "[MoveAction] destructor called!!! \n";}
*/
