#ifndef _COORDINATE_PAIR_
#define _COORDINATE_PAIR_

#include <iostream>
#include <tuple>
#include <cmath>

using CoordinatePair = std::pair<float, float>;

inline CoordinatePair operator-(const CoordinatePair& lhs, const CoordinatePair& rhs) {
	return CoordinatePair(lhs.first-rhs.first, lhs.second-rhs.second);
}
inline float angle(const CoordinatePair& lhs, const CoordinatePair& rhs) {
	auto d = rhs - lhs;
	return atan2(d.second, d.first);
}
inline float norm(const CoordinatePair& vec) {
	return sqrt(vec.first*vec.first + vec.second*vec.second);
}
inline CoordinatePair& operator/=(CoordinatePair& vec, const float& a){
	vec.first /= a;
	vec.second /= a;
	return vec;
}
inline CoordinatePair& operator*=(CoordinatePair& vec, const float& a){
	vec.first *= a;
	vec.second *= a;
	return vec;
}
inline CoordinatePair& operator+=(CoordinatePair& lhs, const CoordinatePair& rhs){
	lhs.first += rhs.first;
	lhs.second += rhs.second;
	return lhs;
}
inline std::ostream& operator<<(std::ostream& os, const CoordinatePair& vec) {
	os << '(' << vec.first << ", " << vec.second << ')';
	return os;
}

#endif
