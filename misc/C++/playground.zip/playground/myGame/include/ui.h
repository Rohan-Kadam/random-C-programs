#ifndef _UI_
#define _UI_

#include <experimental/executor>
#include <SDL.h>
#include <game.h>

class Ui {
public:
	Ui();
	~Ui();
	void run(GameEngine&);
	SDL_Window* window() {return win_;}
private:
	SDL_Window* win_;
};

#endif
