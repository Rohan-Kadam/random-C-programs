#ifndef _GRAPHICS_
#define _GRAPHICS_

#include <memory>
#include <vector>
#include <experimental/executor>
#include <SDL.h>
#include <SDL_image.h>
#include <common.h>
#include <game.h>

using namespace std::experimental;

class GraphicsObject {
public:
	virtual const Position& position() const {return {{0.0,0.0},0.0};}
	virtual void render(SDL_Renderer* ren);
};

class MovableGraphicsObject : public GraphicsObject {
public:
	const Position& position() const override;
	static std::shared_ptr<MovableGraphicsObject> make_new(SDL_Renderer* ren, std::shared_ptr<MovableObject> obj_ptr, std::string model);
	void render(SDL_Renderer* ren) override;
	~MovableGraphicsObject();
private:
	MovableGraphicsObject(SDL_Renderer* ren, std::shared_ptr<MovableObject> obj_ptr, std::string model);
	std::shared_ptr<const MovableObject> obj_ptr_;
	const MovableObject& obj_;
	std::string model_;
	SDL_Texture* model_tex_;
};

class GraphicsEngine {
public:
	GraphicsEngine(SDL_Window* win);
	~GraphicsEngine();
	void run();
	void stop();
	void insert_obj(std::shared_ptr<GraphicsObject>);
	void remove_obj(GraphicsObject*);
	std::shared_ptr<MovableGraphicsObject> make_new_movable_object(std::shared_ptr<MovableObject> obj_ptr, std::string model) { auto obj = MovableGraphicsObject::make_new(renderer_, obj_ptr, model); insert_obj(obj); return obj;}
private:
	void render_frame();
	thread_pool ex_;
	SDL_Renderer* renderer_;			// we are the owner
	bool stop_requested_ = false;
	std::vector<std::shared_ptr<GraphicsObject>> objs_; // not the owner of any element in this set
};


// this is very bad... ignore.. we use it only for background so... ditch...
// To be changed later...
class StaticGraphicsObject : public GraphicsObject {
public:
	StaticGraphicsObject(const std::string& f): fname_{f}, tex_ {nullptr} {};
	~StaticGraphicsObject(){
		if (tex_) SDL_DestroyTexture(tex_);
	}
	void render(SDL_Renderer* ren) override {
		if (!tex_){
			auto surf = IMG_Load(fname_.data());
			if(!surf) throw std::runtime_error{std::string{"IMG_Load error: "} + SDL_GetError()};
			tex_ = SDL_CreateTextureFromSurface(ren, surf);
			if(!tex_) throw std::runtime_error{std::string{"SDL_CreateTextureFromSurface error: "} + SDL_GetError()};
		}
		SDL_RenderCopy(ren, tex_, NULL, NULL);
	}
private:
	std::string fname_;
	SDL_Texture* tex_; // we are the owner
};

#endif
