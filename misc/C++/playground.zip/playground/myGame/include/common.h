#ifndef _COMMON_
#define _COMMON_

#include  <coordinatepair.hpp>

struct Position {
	CoordinatePair location;	// dist. units
	float orientation;	// radians
};

#endif
