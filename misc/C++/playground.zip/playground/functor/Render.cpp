#include <iostream>
#include <vector>
#include <tuple>
#include <cmath>
#include <algorithm>

using namespace std;

using CoordinatePair = std::pair<float, float>;

inline CoordinatePair operator-(const CoordinatePair& lhs, const CoordinatePair& rhs) {
	return CoordinatePair(lhs.first-rhs.first, lhs.second-rhs.second);
}
inline float length(const CoordinatePair& vec) {
	return sqrt(vec.first*vec.first + vec.second*vec.second);
}
inline float dist(const CoordinatePair& a, const CoordinatePair& b) {
	return length(a-b);
}
inline std::ostream& operator<<(std::ostream& os, const CoordinatePair& vec) {
	os << '(' << vec.first << ", " << vec.second << ')';
	return os;
}

struct Object {
	string name;
	CoordinatePair pos;
};
int main() {
	vector<Object> objects {
		{"A",{5.9,4.5}},
		{"B",{4.1,3.8}},
		{"C",{4.4,5.1}}
	};
	{
		CoordinatePair camera {0,0};
		sort(objects.begin(), objects.end(), [camera](const Object& a, const Object&b)->bool {
			return dist(a.pos, camera) > dist(b.pos, camera);
		});

		cout << "Z-order w.r.t " << camera << ":\n";
		// This is just a loop
		for(auto& obj : objects){
			cout << obj.name << " dist: " << dist(obj.pos, camera) << "\n";
		}
	}
	cout << "\n";
	{
		CoordinatePair camera {8,0};
		// same as above, but capturing camera by reference:
		sort(objects.begin(), objects.end(), [&camera](const Object& a, const Object&b)->bool {
			return dist(a.pos, camera) > dist(b.pos, camera);
		});

		cout << "Z-order w.r.t " << camera << ":\n";
		// same as above loop, but with more *flair*
		for_each(objects.begin(), objects.end(), [&camera](const Object& obj) {
			cout << obj.name << " dist: " << dist(obj.pos, camera) << "\n";
		});
	}
	return 0;
}
