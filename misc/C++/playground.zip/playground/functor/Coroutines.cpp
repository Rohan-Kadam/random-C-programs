#include <iostream>
#include <boost/coroutine2/all.hpp>

using namespace std;
using push_type = boost::coroutines2::coroutine<void>::push_type;
using pull_type = boost::coroutines2::coroutine<void>::pull_type;

void some_function(push_type& yield) {
	cout << "[some_function] I am over here now!\n";
	yield();
	cout << "[some_function] Zap!\n";
	yield();
	cout << "[some_function]        Blown!\n";
	return;
}

int main(){
	cout << "[    main     ] Hi! I am over here.\n";
	pull_type co_routine{some_function};
	cout << "[    main     ] Zip!\n";
	co_routine();
	cout << "[    main     ] Mind =\n";
	co_routine();
	cout << "[    main     ] I'll shutup now...\n";
	return 0;
}
