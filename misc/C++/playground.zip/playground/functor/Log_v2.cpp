#include <iostream>
using namespace std;

enum LogLevel {
	Debug = 0, Info, Warn, Error
};

class Log {
public:
	Log():count_{0} {};
	void operator()(LogLevel level, string txt) {
		const char* prefix;
		const char* postfix = "\033[0m\n";
		switch (level) {
			case Debug:
				prefix = "[Debug] ";
				postfix = "\n";
				break;
			case Info:
				prefix = "\033[32;40m[Info]  ";
				// See https://stackoverflow.com/questions/2616906/how-do-i-output-coloured-text-to-a-linux-terminal
				break;
			case Warn:
				prefix = "\033[33;40m[Warn]  ";
				break;
			default:
				prefix = "\033[31;40m[Error] ";
		}
		cerr << prefix << "("<< ++count_ << ") " << txt << postfix;
	}
private:
	int count_;		// T: "_" for private memmbers 
};

int main() {
	Log log;
	cout << "sizeof(Log): " << sizeof(Log) << "\n";
	log(Debug, "This is debug text");
	log(Info, "This is info text");
	log(Warn, "This is warning text");
	log(Error, "This is error text");
	return 0;
}
