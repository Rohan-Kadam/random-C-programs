#include <iostream>

using namespace std;

enum LogLevel {
	Debug = 0, Info, Warn, Error
};


void log(LogLevel level, string txt) {
	static int count_ = 0;     // T: "_" for private memmbers 
	const char* prefix;
	const char* postfix = "\033[0m\n";
	switch (level) {
		case Debug:
			prefix = "[Debug] ";
			postfix = "\n";
			break;
		case Info:
			prefix = "\033[32;40m[Info ] ";
			// See https://stackoverflow.com/questions/2616906/how-do-i-output-coloured-text-to-a-linux-terminal
			break;
		case Warn:
			prefix = "\033[33;40m[Warn ] ";
			break;
		default:
			prefix = "\033[31;40m[Error] ";
	}
	cerr << prefix << "("<< ++count_ << ") " << txt << postfix;
}

int main() {
	log(Debug, "This is debug text");
	log(Info, "This is info text");
	log(Warn, "This is warning text");
	log(Error, "This is error text");
	return 0;
}
