#include <iostream>
#include <cstring>
using namespace std;

class String{
public:
	String(const char*);
	String(const String&);
	~String();
private:
	char* data_;
	friend ostream& operator << (ostream&, const String&);
};
String::String(const char* s) {
	data_ = new char[strlen(s)+1];
	strcpy(data_, s);
	cout << "obj: @" << this << " [constructor] new data_: @" << static_cast<void*>(data_) << "\n";
}
String::String(const String& other) {
	data_ = new char[strlen(other.data_)];
	strcpy(data_, other.data_);
	cout << "obj: @" << this << " [copy constructor <- other: @" << &other << " ] new data_: @" << static_cast<void*>(data_) << "\n";
}
String::~String() {
	delete[] data_;
	cout << "obj: @" << this << " [destructor] delete data_ :@" << static_cast<void*>(data_) << "\n";
}
ostream& operator << (ostream& os, const String& s) {
	os << "obj: @" << &s << " [print] data_: @" << static_cast<void*>(s.data_) << " contents: " << s.data_ << "\n";
	return os;
}

void in_function_cv(String s){
	cout << s;   //copy constructor is called
}
void in_function_cr(String& s){
	cout << s;
}
String out_function() {
	String s("welcome to c++");
	cout << s;
	return s;
}
int main() {
	cout << "************* creating str ******************\n";
	String str("hello world!");
	cout << "******* passing String (by value) ********\n";
	in_function_cv(str);
	cout << "******* passing String (by ref) **********\n";
	in_function_cr(str);     //pass a clone of object, hence no copy constructor is called
	cout << "********** returning String **************\n";
	String str2 = out_function();    //this function also calls copy constructor
	cout << "**************** exiting ********************\n";
	return 0;
}
