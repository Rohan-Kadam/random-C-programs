//smart pointer


#include <iostream>
using namespace std;

class Shared_ptr {
public:
	explicit Shared_ptr(char* resource) :
		ref_count_ {new int{1}},
		resource_{resource} {
		cout << "[constructor] resource_: " << static_cast<void*>(resource_) << " ref_count: " << *ref_count_ << "\n";
	}

	~Shared_ptr() {
		cout << "[destructor] resource_: " << static_cast<void*>(resource_) << " ref_count: " << *ref_count_ ;
		decrement_ref_count();
	}

	Shared_ptr(const Shared_ptr& other) :
		ref_count_{other.ref_count_},
		resource_{other.resource_} {
		++*ref_count_;
		cout << "[copy constructor] resource_: " << static_cast<void*>(resource_) << " ref_count: " << *ref_count_ << "\n";
	}

	Shared_ptr& operator=(const Shared_ptr& other) {
		cout << "[copy assignment] old resource_: " << static_cast<void*>(resource_) << " old ref_count: " << *ref_count_;
		decrement_ref_count();
		ref_count_ = other.ref_count_;
		resource_ = other.resource_;
		++*ref_count_;
		cout << "[      ..       ] resource_: " << static_cast<void*>(resource_) << " ref_count: " << *ref_count_ << "\n";
		return *this;
	}

	char* get() {return resource_;}
	const char* get() const {return resource_;}
	int ref_count() const {return *ref_count_;}
private:
	void decrement_ref_count(){
		if(ref_count_ && !--*ref_count_) {
			delete [] resource_;
			delete ref_count_;
			resource_ = nullptr;
			ref_count_ = nullptr;
			cout << " deleted resource_\n";
			return;
		}
		cout << " not deleting resource_\n";
	}
	int* ref_count_;
	char* resource_;
};

int main() {
	{
		Shared_ptr p1 {new char[1024]};
	}
	cout << "******** scope ended **********\n";
	Shared_ptr p2 {new char[1024]};
	{
		Shared_ptr p3 = p2;
		{
			Shared_ptr p4 {new char[1024]};
			p3 = p4;
		}
		cout << "******** scope ended **********\n";
	}
	cout << "******** scope ended **********\n";
}
