#include <iostream>
#include <cstring>
using namespace std;

class String{
public:
	String(const char*);
	String(const String&);
	String(String&&);
	~String();
private:
	char* data_;
	friend ostream& operator << (ostream&, const String&);
};
String::String(const char* s) {
	data_ = new char[strlen(s)+1];
	strcpy(data_, s);
	cout << "obj: @" << this << " [constructor] new data_: @" << static_cast<void*>(data_) << "\n";
}
String::String(const String& other) {
	data_ = new char[strlen(other.data_)];
	strcpy(data_, other.data_);
	cout << "obj: @" << this << " [copy constructor <- other: @" << &other << " ] new data_: @" << static_cast<void*>(data_) << "\n";
}
String::String(String&& other) {
	data_ = other.data_;
	other.data_ = nullptr;
	cout << "obj: @" << this << " [move constructor <- other: @" << &other << " ] data_: @" << static_cast<void*>(data_) << "\n";
}
String::~String() {
	cout << "obj: @" << this << " [destructor]";
	if(data_) {
		delete[] data_;
		cout << " delete data_ :@" << static_cast<void*>(data_) << "\n";
	}else
		cout << " data_ is not deleted\n";
}
ostream& operator << (ostream& os, const String& s) {
	os << "obj: @" << &s << " [print]";
	if (s.data_) os << " data_: @" << static_cast<void*>(s.data_) << " contents: " << s.data_ << "\n";
	else os << " data_: nullptr\n";
	return os;
}

void in_function_cv(String s){
	cout << s;
}
void in_function_cr(String& s){
	cout << s;
}
String out_function() {
	String s("welcome to c++");
	cout << s;
	return s;
}
int main() {
	cout << "************* creating str ******************\n";
	String str("hello world!");
	cout << "******* passing String (by value) ********\n";
	in_function_cv(str);
	cout << "******* passing String (by ref) **********\n";
	in_function_cr(str);
	cout << "********** returning String **************\n";
	String str2 = out_function();
	cout << "******* passing String (by move) *********\n";
	String str3("hope you are having fun");
	in_function_cv(std::move(str3));
	cout << str3;
	cout << "**************** exiting ********************\n";
	return 0;
}
