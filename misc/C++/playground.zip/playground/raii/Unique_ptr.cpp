#include <iostream>
using namespace std;

class Unique_ptr {
public:
	explicit Unique_ptr(char* resource) : resource_{resource} {
		cout << "[constructor] owning resource_: " << static_cast<void*>(resource_) <<"\n";
	}
	~Unique_ptr() {
		cout << "[destructor] ";
		if(resource_) {
			cout << "delete owned resource_: " << static_cast<void*>(resource_) << "\n";
			delete[] resource_;
		}else{
			cout << "not owning any resource\n";
		}

	}
	Unique_ptr(const Unique_ptr& other) = delete;
	Unique_ptr& operator=(const Unique_ptr& other) = delete;

	Unique_ptr(Unique_ptr&& other) {
		resource_ = other.resource_;
		other.resource_ = nullptr;
		cout << "[move constructor] transfered ownership of resource_: " << static_cast<void*>(resource_) << "\n";
	}
	Unique_ptr& operator=(Unique_ptr&& other) {
		if(resource_) {
			cout << "[move assignment] delete old resource_: " << static_cast<void*>(resource_) << "\n";
			delete[] resource_;
		}else {
			cout << "[move assignment] no old resource_: " << static_cast<void*>(resource_) << "\n";
		}
		resource_ = other.resource_;
		other.resource_ = nullptr;
		cout << "[      ..       ] transfered ownership of resource_: " << static_cast<void*>(resource_) << "\n";
		return *this;
	}

	char* get() {return resource_;}
	const char* get() const {return resource_;}
private:
	char* resource_;
};

int main() {
	{
		Unique_ptr p1 {new char[1024]};
	}
	cout << "******** scope ended **********\n";
	Unique_ptr p2 {new char[1024]};
	{
		Unique_ptr p3 = move(p2);
		{
			Unique_ptr p4 {new char[1024]};
			p3 = move(p4);
		}
		cout << "******** scope ended **********\n";
	}
	cout << "******** scope ended **********\n";
	return 0;
}
