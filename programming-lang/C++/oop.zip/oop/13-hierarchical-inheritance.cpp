/*
 *
 * Class B and C inherits class A
 *
 */

#include <iostream>
using namespace std;
class A {
public:
  A(){
     cout<<"Constructor of A class"<<endl;
  }
};
class B: public A {
public:
  B(){
     cout<<"Constructor of B class"<<endl;
  }
};
class C: public A{
public:
  C(){
     cout<<"Constructor of C class"<<endl;
  }
};
int main() {
   //Creating object of class C
   C obj;
   B obj2;
   cout<<"B --> A"<<endl;
   cout<<"C --> A"<<endl;
   return 0;
}
